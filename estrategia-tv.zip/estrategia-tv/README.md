# Estratégia TV — WebView App para Android TV

APK mínimo que abre https://med.estrategia.com/mesa-de-estudo/ em tela cheia.

---

## Como buildar (Android Studio — mais fácil)

1. Instale o [Android Studio](https://developer.android.com/studio)
2. Abra esta pasta como projeto ("Open an existing project")
3. Aguarde o Gradle sincronizar
4. Menu → **Build → Build APK(s)**
5. O APK estará em `app/build/outputs/apk/debug/app-debug.apk`

---

## Como buildar (linha de comando)

### Pré-requisitos
- Java 17+ (`java -version`)
- Android SDK instalado (via Android Studio ou `sdkmanager`)
- Variável `ANDROID_HOME` apontando pro SDK

### Passos
```bash
cd estrategia-tv
chmod +x gradlew          # Linux/macOS
./gradlew assembleDebug   # Linux/macOS
gradlew assembleDebug     # Windows
```
APK gerado em: `app/build/outputs/apk/debug/app-debug.apk`

---

## Como instalar na Mi Stick TV via Wi-Fi

### 1. Habilitar depuração Wi-Fi na TV
- Configurações → Sobre → Clique 7x em "Build number" (ativa modo dev)
- Configurações → Opções do desenvolvedor → Depuração ADB (ativar)
- Anote o IP da TV (Configurações → Rede → Ver IP)

### 2. Conectar e instalar
```bash
# Instale o ADB no PC se não tiver:
# Ubuntu: sudo apt install adb
# Mac:    brew install android-platform-tools
# Windows: baixe platform-tools da Google

adb connect <IP_DA_TV>:5555
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 3. Abrir o app
- Procure "Estratégia" nos apps instalados
- Ou via ADB:
```bash
adb shell am start -n com.mateus.estrategiatv/.MainActivity
```

---

## Notas
- O app permite login pelo Google (accounts.google.com), pois o site precisa
- Navegação é contida dentro do domínio estrategia.com
- Botão voltar do controle navega no histórico do navegador interno
